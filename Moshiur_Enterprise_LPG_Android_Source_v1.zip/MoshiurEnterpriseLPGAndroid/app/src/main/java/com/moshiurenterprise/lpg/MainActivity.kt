package com.moshiurenterprise.lpg

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import java.text.NumberFormat
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FirebaseApp.initializeApp(this)
        setContent { MaterialTheme { LPGApp() } }
    }
}

private data class Entry(
    val id: String = "",
    val type: String = "",
    val date: String = "",
    val title: String = "",
    val amount: Double = 0.0,
    val due: Double = 0.0,
    val cylinderSize: String = "",
    val quantity: Long = 0
)

private fun taka(value: Double): String =
    "৳" + NumberFormat.getNumberInstance(Locale("bn", "BD")).format(value)

@Composable
private fun LPGApp() {
    val auth = remember { FirebaseAuth.getInstance() }
    val db = remember { FirebaseFirestore.getInstance() }
    var user by remember { mutableStateOf(auth.currentUser) }
    var page by remember { mutableStateOf("home") }
    var entries by remember { mutableStateOf(listOf<Entry>()) }
    var message by remember { mutableStateOf("") }

    fun loadEntries() {
        val uid = auth.currentUser?.uid ?: return
        db.collection("users").document(uid).collection("entries")
            .orderBy("createdAt", com.google.firebase.firestore.Query.Direction.DESCENDING)
            .limit(100).get()
            .addOnSuccessListener { snap ->
                entries = snap.documents.map { d ->
                    Entry(
                        id = d.id,
                        type = d.getString("type") ?: "",
                        date = d.getString("date") ?: "",
                        title = d.getString("title") ?: "",
                        amount = d.getDouble("amount") ?: 0.0,
                        due = d.getDouble("due") ?: 0.0,
                        cylinderSize = d.getString("cylinderSize") ?: "",
                        quantity = d.getLong("quantity") ?: 0L
                    )
                }
            }
            .addOnFailureListener { message = "ডাটা লোড হয়নি: ${it.localizedMessage}" }
    }

    LaunchedEffect(user) { if (user != null) loadEntries() }

    if (user == null) {
        AuthScreen(
            onLogin = { email, pass ->
                auth.signInWithEmailAndPassword(email, pass)
                    .addOnSuccessListener { user = auth.currentUser; message = "লগইন সফল" }
                    .addOnFailureListener { message = "লগইন হয়নি: ${it.localizedMessage}" }
            },
            onRegister = { email, pass ->
                auth.createUserWithEmailAndPassword(email, pass)
                    .addOnSuccessListener { user = auth.currentUser; message = "অ্যাকাউন্ট তৈরি হয়েছে" }
                    .addOnFailureListener { message = "অ্যাকাউন্ট তৈরি হয়নি: ${it.localizedMessage}" }
            },
            message = message
        )
    } else {
        Scaffold(
            topBar = {
                TopAppBarCompat(
                    title = "মেসার্স মশিউর এন্টারপ্রাইজ",
                    onLogout = { auth.signOut(); user = null }
                )
            },
            bottomBar = {
                NavigationBar {
                    listOf("home" to "হোম", "sale" to "বিক্রয়", "purchase" to "ক্রয়",
                        "expense" to "খরচ", "report" to "রিপোর্ট").forEach { (key, label) ->
                        NavigationBarItem(
                            selected = page == key,
                            onClick = { page = key },
                            icon = { Text(if (key == "home") "⌂" else if (key == "sale") "৳" else if (key == "purchase") "＋" else if (key == "expense") "−" else "▤") },
                            label = { Text(label) }
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.padding(padding).fillMaxSize().padding(16.dp)) {
                if (message.isNotBlank()) {
                    Text(message, color = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.height(8.dp))
                }
                when (page) {
                    "home" -> Dashboard(entries, onRefresh = { loadEntries() })
                    "sale" -> EntryForm("বিক্রয় এন্ট্রি", "sale") { data ->
                        saveEntry(db, user!!.uid, data) { ok, msg ->
                            message = msg
                            if (ok) loadEntries()
                        }
                    }
                    "purchase" -> EntryForm("ক্রয় এন্ট্রি", "purchase") { data ->
                        saveEntry(db, user!!.uid, data) { ok, msg ->
                            message = msg
                            if (ok) loadEntries()
                        }
                    }
                    "expense" -> EntryForm("খরচ এন্ট্রি", "expense") { data ->
                        saveEntry(db, user!!.uid, data) { ok, msg ->
                            message = msg
                            if (ok) loadEntries()
                        }
                    }
                    else -> ReportScreen(entries)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TopAppBarCompat(title: String, onLogout: () -> Unit) {
    TopAppBar(
        title = { Text(title, style = MaterialTheme.typography.titleMedium) },
        actions = { TextButton(onClick = onLogout) { Text("লগআউট") } }
    )
}

@Composable
private fun AuthScreen(
    onLogin: (String, String) -> Unit,
    onRegister: (String, String) -> Unit,
    message: String
) {
    var email by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var create by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("মশিউর এন্টারপ্রাইজ", style = MaterialTheme.typography.headlineSmall)
        Text("LPG ব্যবসা ব্যবস্থাপনা", color = MaterialTheme.colorScheme.secondary)
        Spacer(Modifier.height(24.dp))
        OutlinedTextField(email, { email = it }, label = { Text("ইমেইল") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(pass, { pass = it }, label = { Text("পাসওয়ার্ড") },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        Button(onClick = { if (create) onRegister(email.trim(), pass) else onLogin(email.trim(), pass) },
            modifier = Modifier.fillMaxWidth()) { Text(if (create) "অ্যাকাউন্ট তৈরি করুন" else "লগইন") }
        TextButton(onClick = { create = !create }) {
            Text(if (create) "আগে অ্যাকাউন্ট আছে? লগইন করুন" else "প্রথমবার? অ্যাকাউন্ট তৈরি করুন")
        }
        if (message.isNotBlank()) Text(message, color = MaterialTheme.colorScheme.error)
        Text("এই অ্যাপটি আপনার ব্যক্তিগত ব্যবসার হিসাবের জন্য।", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun Dashboard(entries: List<Entry>, onRefresh: () -> Unit) {
    val sales = entries.filter { it.type == "sale" }
    val todaySales = sales.sumOf { it.amount }
    val due = sales.sumOf { it.due }
    Text("ব্যবসার ড্যাশবোর্ড", style = MaterialTheme.typography.headlineSmall)
    Spacer(Modifier.height(12.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        MetricCard("মোট বিক্রয়", taka(todaySales), Modifier.weight(1f))
        MetricCard("বিক্রয়ের বাকি", taka(due), Modifier.weight(1f))
    }
    Spacer(Modifier.height(12.dp))
    Button(onClick = onRefresh) { Text("ডাটা রিফ্রেশ") }
    Spacer(Modifier.height(12.dp))
    Text("সাম্প্রতিক হিসাব", style = MaterialTheme.typography.titleMedium)
    EntryList(entries.take(12))
}

@Composable
private fun MetricCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier) {
        Column(Modifier.padding(14.dp)) {
            Text(label, style = MaterialTheme.typography.bodySmall)
            Text(value, style = MaterialTheme.typography.titleLarge)
        }
    }
}

@Composable
private fun EntryForm(title: String, type: String, onSave: (Map<String, Any>) -> Unit) {
    var date by remember { mutableStateOf(java.time.LocalDate.now().toString()) }
    var name by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var due by remember { mutableStateOf("0") }
    var size by remember { mutableStateOf("12 কেজি") }
    var qty by remember { mutableStateOf("1") }
    var note by remember { mutableStateOf("") }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Text(title, style = MaterialTheme.typography.headlineSmall) }
        item { OutlinedTextField(date, { date = it }, label = { Text("তারিখ (YYYY-MM-DD)") }, modifier = Modifier.fillMaxWidth()) }
        item { OutlinedTextField(name, { name = it }, label = { Text(if (type == "expense") "খরচের বিবরণ" else if (type == "purchase") "সাপ্লায়ারের নাম" else "কাস্টমারের নাম") }, modifier = Modifier.fillMaxWidth()) }
        if (type != "expense") {
            item {
                var expanded by remember { mutableStateOf(false) }
                ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                    OutlinedTextField(size, {}, readOnly = true, label = { Text("সিলিন্ডারের সাইজ") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth())
                    ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        listOf("12 কেজি", "15 কেজি", "20 কেজি", "30 কেজি", "35 কেজি", "45 কেজি").forEach {
                            DropdownMenuItem(text = { Text(it) }, onClick = { size = it; expanded = false })
                        }
                    }
                }
            }
            item { OutlinedTextField(qty, { qty = it }, label = { Text("পরিমাণ (টি)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth()) }
        }
        item { OutlinedTextField(amount, { amount = it }, label = { Text("মোট টাকা (৳)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth()) }
        if (type == "sale") item { OutlinedTextField(due, { due = it }, label = { Text("বাকি টাকা (৳)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth()) }
        item { OutlinedTextField(note, { note = it }, label = { Text("নোট (ঐচ্ছিক)") }, modifier = Modifier.fillMaxWidth()) }
        item {
            Button(onClick = {
                val a = amount.toDoubleOrNull()
                if (name.isBlank() || a == null || a < 0) return@Button
                onSave(mapOf(
                    "type" to type, "date" to date, "title" to name.trim(),
                    "amount" to a, "due" to (if (type == "sale") due.toDoubleOrNull() ?: 0.0 else 0.0),
                    "cylinderSize" to size, "quantity" to (qty.toLongOrNull() ?: 0L),
                    "note" to note, "createdAt" to System.currentTimeMillis()
                ))
                name = ""; amount = ""; due = "0"; qty = "1"; note = ""
            }, modifier = Modifier.fillMaxWidth()) { Text("অনলাইনে সংরক্ষণ করুন") }
        }
    }
}

private fun saveEntry(
    db: FirebaseFirestore,
    uid: String,
    data: Map<String, Any>,
    done: (Boolean, String) -> Unit
) {
    db.collection("users").document(uid).collection("entries").add(data)
        .addOnSuccessListener { done(true, "তথ্য অনলাইনে সংরক্ষণ হয়েছে") }
        .addOnFailureListener { done(false, "সংরক্ষণ হয়নি: ${it.localizedMessage}") }
}

@Composable
private fun ReportScreen(entries: List<Entry>) {
    val sales = entries.filter { it.type == "sale" }.sumOf { it.amount }
    val purchase = entries.filter { it.type == "purchase" }.sumOf { it.amount }
    val expense = entries.filter { it.type == "expense" }.sumOf { it.amount }
    Text("রিপোর্ট", style = MaterialTheme.typography.headlineSmall)
    Spacer(Modifier.height(12.dp))
    MetricCard("মোট বিক্রয়", taka(sales), Modifier.fillMaxWidth())
    Spacer(Modifier.height(8.dp))
    MetricCard("মোট ক্রয়", taka(purchase), Modifier.fillMaxWidth())
    Spacer(Modifier.height(8.dp))
    MetricCard("মোট খরচ", taka(expense), Modifier.fillMaxWidth())
    Spacer(Modifier.height(8.dp))
    MetricCard("বিক্রয় - ক্রয় - খরচ (সরল হিসাব)", taka(sales - purchase - expense), Modifier.fillMaxWidth())
    Text("এটি প্রাথমিক সারাংশ; পূর্ণ লাভ-লোকসান ও স্টক মূল্যায়ন পরবর্তী সংস্করণে সম্পূর্ণ করা হবে।",
        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
}

@Composable
private fun EntryList(entries: List<Entry>) {
    LazyColumn {
        items(entries) { item ->
            ListItem(
                headlineContent = { Text(item.title) },
                supportingContent = { Text("${item.date} · ${item.type} · ${item.cylinderSize} ${item.quantity} টি") },
                trailingContent = { Text(taka(item.amount)) }
            )
            HorizontalDivider()
        }
    }
}
