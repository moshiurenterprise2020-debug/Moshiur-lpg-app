মশিউর এন্টারপ্রাইজ LPG Android App — Source Project v1

এই ZIP-এ Android Studio-তে খোলার মতো Kotlin + Jetpack Compose সোর্স প্রজেক্ট আছে।
এটি এখনই APK নয়। Firebase কনফিগার করে Android Studio থেকে Build APK করতে হবে।

প্রয়োজন:
- কম্পিউটারে Android Studio (নতুন stable সংস্করণ)
- ইন্টারনেট
- Firebase/Google অ্যাকাউন্ট

Firebase সেটআপ:
1. https://console.firebase.google.com এ নতুন Project তৈরি করুন।
2. Android app যোগ করুন। Package name দিন: com.moshiurenterprise.lpg
3. Firebase থেকে google-services.json ডাউনলোড করে app/ ফোল্ডারে রাখুন।
4. Firebase Authentication > Sign-in method থেকে Email/Password চালু করুন।
5. Firestore Database তৈরি করুন।
6. Firestore Rules অংশে এই ZIP-এর firestore.rules ফাইলের নিয়ম প্রকাশ করুন।
7. Android Studio-তে এই ফোল্ডার Open করুন, Gradle Sync শেষ হতে দিন।
8. Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।
9. APK সাধারণত app/build/outputs/apk/debug/app-debug.apk এ তৈরি হবে।

গুরুত্বপূর্ণ নিরাপত্তা:
- Firestore Rules-এ ব্যবহারকারী কেবল নিজের UID-র ডাটা পড়তে/লিখতে পারবে।
- নিজের ব্যক্তিগত ইমেইল দিয়ে প্রথমবার অ্যাকাউন্ট তৈরি করুন; অন্য কাউকে অ্যাকাউন্ট দেবেন না।
- google-services.json এখানে ইচ্ছাকৃতভাবে নেই; এটি আপনার Firebase project-এর নিজস্ব ফাইল।
- Firebase কনফিগারেশন ছাড়া অনলাইন লগইন/ডাটা সংরক্ষণ কাজ করবে না।

বর্তমান প্রোটোটাইপের সীমাবদ্ধতা:
- এটি প্রাথমিক কাজের সোর্স। পূর্ণ স্টক লেজার, সিলিন্ডার ফেরত/খালি হিসাব, supplier/customer ledger,
  invoice PDF/print, date-wise profit and loss, data export এবং production hardening এখনো বাকি।
- বাস্তব ব্যবসায় ব্যবহার করার আগে পরীক্ষামূলক ডাটা দিয়ে হিসাব যাচাই করুন।
- APK সাইনিং/Play Store প্রকাশের আগে release build ও নিরাপত্তা পরীক্ষা দরকার।
