// আপনার দেওয়া Firebase Web App config এখানে রাখা হয়েছে।
// Web API key সাধারণত public client config; Service Account private key কখনো এখানে দেবেন না।
export const firebaseConfig = {
  apiKey: "AIzaSyA5a_caW76kRjeaEpnmI45vZ2N9sX3OVL4",
  authDomain: "moshiur-enterprise.firebaseapp.com",
  projectId: "moshiur-enterprise",
  storageBucket: "moshiur-enterprise.firebasestorage.app",
  messagingSenderId: "500233554657",
  appId: "1:500233554657:web:329ad7cc5429e7ddea05a0",
  measurementId: "G-YQ71RPYDZS"
};
