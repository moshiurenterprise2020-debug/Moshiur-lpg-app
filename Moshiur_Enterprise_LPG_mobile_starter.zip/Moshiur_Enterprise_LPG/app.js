const KEY='moshiur_lpg_entries_v1';
const entries=()=>JSON.parse(localStorage.getItem(KEY)||'[]');
const money=n=>'৳'+Number(n||0).toLocaleString('bn-BD',{maximumFractionDigits:2});
function render(){
 const all=entries(), today=new Date().toISOString().slice(0,10), todays=all.filter(x=>x.date===today);
 const sum=k=>todays.filter(x=>x.kind===k).reduce((s,x)=>s+x.total,0);
 document.querySelector('#sales').textContent=money(sum('sale'));
 document.querySelector('#purchases').textContent=money(sum('purchase'));
 document.querySelector('#expenses').textContent=money(sum('expense'));
 document.querySelector('#collections').textContent=money(sum('collection'));
 document.querySelector('#items').innerHTML=all.slice(-12).reverse().map(x=>`<div class="entry"><b>${({sale:'বিক্রি',purchase:'ক্রয়',expense:'খরচ',collection:'বাকি আদায়'})[x.kind]}</b> — ${escapeHtml(x.note||'বিবরণ নেই')}<div class="muted">${x.date} · ${x.qty} × ${money(x.price)} = ${money(x.total)}</div></div>`).join('')||'<p class="muted">এখনো কোনো হিসাব যোগ হয়নি।</p>';
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
document.querySelector('#save').addEventListener('click',()=>{
 const kind=document.querySelector('#kind').value,note=document.querySelector('#note').value.trim();
 const qty=Number(document.querySelector('#qty').value),price=Number(document.querySelector('#price').value);
 if(!(qty>0)||price<0||!Number.isFinite(qty+price)){document.querySelector('#msg').textContent='পরিমাণ ও দর সঠিকভাবে লিখুন।';return;}
 const item={id:crypto.randomUUID(),kind,note,qty,price,total:qty*price,date:new Date().toISOString().slice(0,10)};
 const all=entries();all.push(item);localStorage.setItem(KEY,JSON.stringify(all));
 document.querySelector('#note').value='';document.querySelector('#msg').textContent='হিসাব সংরক্ষণ হয়েছে।';render();
});
document.querySelector('#refresh').addEventListener('click',render);
document.querySelector('#export').addEventListener('click',()=>{
 const blob=new Blob([JSON.stringify(entries(),null,2)],{type:'application/json'});
 const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='moshiur-lpg-backup.json';a.click();URL.revokeObjectURL(a.href);
});
if('serviceWorker' in navigator) window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));
render();
